import pysam
HIFI="https://s3-us-west-2.amazonaws.com/human-pangenomics/submissions/40399FDD-59DE-43D1-B3A3-DFF0C6E64FAC--YALE_VARIANT_CALLS_R2/samples/HG01943/alignments/GRCh38_no_alt/hifi_reads/HG01943.GRCh38_no_alt.sorted.bam"
def rc(s): return s[::-1].translate(str.maketrans('ACGTN','TGCAN'))
CT="TTCCACTGCTCTGG"      # end ...TTCCA + CT + GCTCTGG start
PLAIN="TTCCAGCTCTGG"     # plain concatenation 48,057,041|46,970,725
bam=pysam.AlignmentFile(HIFI)
seen={}
for reg in [('chr2',48057041-60,48057041+60),('chr2',46970725-60,46970725+60)]:
    for r in bam.fetch(*reg):
        if r.is_secondary or r.query_sequence is None: continue
        q=r.query_sequence
        if r.query_name in seen: continue
        seen[r.query_name]=( (CT in q) or (rc(CT) in q), (PLAIN in q) or (rc(PLAIN) in q), r.is_supplementary)
n=len(seen); nct=sum(v[0] for v in seen.values()); npl=sum(v[1] for v in seen.values())
print('distinct reads overlapping either breakpoint (primary or supplementary records):', n)
print('reads containing CT-insertion junction 14-mer:', nct)
print('reads containing plain-concatenation 12-mer:', npl)
