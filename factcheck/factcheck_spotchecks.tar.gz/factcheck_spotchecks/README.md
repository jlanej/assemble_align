Spot-check evidence for factcheck_report.md (2026-11-12).
- junc.py / junc2.py / junc_out.txt: HG01943 junction reads at chr2:48,057,041 and 46,970,725 from the HPRC/Yale HiFi GRCh38 BAM (pysam over HTTPS); GRCh38 flanks from the 1kG GRCh38_full_analysis_set_plus_decoy_hla.fa.
- fasta_scan.py / fasta_scan.json: HG01103 trio hifiasm hap1 FASTA streamed; junction 31-mers (track table hg01103_junction_31mers.tsv) searched on the 8 junction-holding contigs; contig count and lengths.
- bam_scan.sh / bam_scan.log: HG01103 published hap1 ASM_to_REF BAM streamed; distinct contigs with records and MAPQ<5 count.
- github_status_2026-11-12.json: GitHub API records (latest releases, PR lh3/minimap2#1361, Qtip commits, minimap2 master vs v2.31).
- the HPRC Minigraph-Cactus v2.1 release README (not redistributed here; see the HPRC release-2 pangenome directory on s3://human-pangenomics): HPRC Minigraph-Cactus v2.1 README (held-out samples).
- verify_dois.json: Crossref/doi.org resolution for the 66 checked DOIs.
