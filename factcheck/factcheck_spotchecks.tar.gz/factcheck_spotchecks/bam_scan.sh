set -euo pipefail
URL=https://1000g-ont.s3.amazonaws.com/1KGP_PacBio_WGS/ASM_to_REF_BAM/trio_asm/GRCh38/HG01103-W-0.hap1.bam
samtools view "$URL" | awk '{print $1"\t"$5}' | sort -u -k1,1 -k2,2n > bam_qnames_mapq.tsv
cut -f1 bam_qnames_mapq.tsv | sort -u > bam_contigs.txt
echo "distinct contigs with records: $(wc -l < bam_contigs.txt)"
awk '$2<5' bam_qnames_mapq.tsv | wc -l | xargs echo "records(qname,mapq) pairs with MAPQ<5:"
for c in h1tg000172l h1tg000204l h1tg000159l h1tg000007l h1tg000025l h1tg000033l h1tg000116l h1tg000031l; do printf "%s\t%s\n" $c $(grep -c -x $c bam_contigs.txt || true); done
