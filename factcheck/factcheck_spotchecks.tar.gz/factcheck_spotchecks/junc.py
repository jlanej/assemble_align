import pysam, sys, collections
REF="https://1000genomes.s3.amazonaws.com/technical/reference/GRCh38_reference_genome/GRCh38_full_analysis_set_plus_decoy_hla.fa"
HIFI="https://s3-us-west-2.amazonaws.com/human-pangenomics/submissions/40399FDD-59DE-43D1-B3A3-DFF0C6E64FAC--YALE_VARIANT_CALLS_R2/samples/HG01943/alignments/GRCh38_no_alt/hifi_reads/HG01943.GRCh38_no_alt.sorted.bam"
fa=pysam.FastaFile(REF)
E=48057041; S=46970725   # 1-based segment end and start
endctx=fa.fetch('chr2',E-30,E+10)   # 0-based: positions E-29..E+10 (1-based)
startctx=fa.fetch('chr2',S-11,S+29) # 1-based S-10..S+29
print('REF end  (1-based %d..%d):'%(E-29,E+10), endctx[:30].upper(),'|',endctx[30:].lower())
print('REF start(1-based %d..%d):'%(S-10,S+29), startctx[:10].lower(),'|',startctx[10:].upper())
bam=pysam.AlignmentFile(HIFI)
out=[]
n=0
for r in bam.fetch('chr2',E-5,E+5):
    if r.is_secondary or r.is_unmapped: continue
    n+=1
    # junction candidate: alignment ends near E with a right soft clip
    ct=r.cigartuples
    if r.reference_end is not None and abs(r.reference_end-E)<=5 and ct[-1][0]==4 and ct[-1][1]>=50:
        q=r.query_sequence
        qend=r.query_alignment_end
        # sequence across the end: last 15 aligned + next 40 clipped
        out.append((r.query_name, r.reference_end, r.mapping_quality, q[qend-15:qend], q[qend:qend+40], r.is_reverse))
print('reads overlapping end window:', n, ' right-clipped near E:', len(out))
for o in out: print(o[0][:40], 'aln_end=%d mq=%d'%(o[1],o[2]), o[3], '|', o[4], 'rev' if o[5] else 'fwd')
# also reads whose alignment starts near S with left soft clip
out2=[]
for r in bam.fetch('chr2',S-5,S+5):
    if r.is_secondary or r.is_unmapped: continue
    ct=r.cigartuples
    if abs(r.reference_start+1-S)<=5 and ct[0][0]==4 and ct[0][1]>=50:
        q=r.query_sequence; qs=r.query_alignment_start
        out2.append((r.query_name, r.reference_start+1, r.mapping_quality, q[qs-40:qs], q[qs:qs+15]))
print('left-clipped near S:', len(out2))
for o in out2: print(o[0][:40], 'aln_start=%d mq=%d'%(o[1],o[2]), o[3], '|', o[4])
