import gzip, urllib.request, sys, collections, json
URL="https://1000g-ont.s3.amazonaws.com/1KGP_PacBio_WGS/Assembly/Trio_Assembly/HG01103-W-0/HG01103-W-0.hifiasm.dip.hap1.p_ctg.gfa.fasta.gz"
def rc(s): return s[::-1].translate(str.maketrans('ACGTN','TGCAN'))
km=collections.defaultdict(list)
for line in open('kmers.tsv'):
    j,s=line.split()
    km[j.split('_')[0]].append(s)
targets={'h1tg000172l','h1tg000204l','h1tg000159l','h1tg000007l','h1tg000025l','h1tg000033l','h1tg000116l','h1tg000031l'}
r=urllib.request.urlopen(URL, timeout=300)
g=gzip.GzipFile(fileobj=r)
lens={}; name=None; buf=[]; hits={}
def finish(name,buf):
    seq=''.join(buf); lens[name]=len(seq)
    if name in targets:
        for J,ks in km.items():
            pos=[]; n=0
            for s in ks:
                p=seq.find(s); q=seq.find(rc(s)) if p<0 else -1
                if p>=0 or q>=0: n+=1; pos.append(p if p>=0 else q)
            if n: hits.setdefault(J,[]).append((name,n,len(ks),min(pos),len(seq)))
for raw in g:
    line=raw.decode().rstrip('\n')
    if line.startswith('>'):
        if name is not None: finish(name,buf)
        name=line[1:].split()[0]; buf=[]
    else: buf.append(line.upper())
if name is not None: finish(name,buf)
out={'n_contigs':len(lens),'total_bp':sum(lens.values()),'target_lengths':{t:lens.get(t) for t in sorted(targets)},'hits':hits,
     'n_junctions_present_ge80pct':sum(1 for J,v in hits.items() if max(x[1]/x[2] for x in v)>=0.8)}
json.dump(out,open('fasta_scan.json','w'),indent=1); json.dump(lens,open('hap1_lengths.json','w'))
print(json.dumps(out,indent=1)[:3000])
